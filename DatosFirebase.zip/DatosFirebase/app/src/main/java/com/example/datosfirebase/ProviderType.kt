package com.example.ejemplofirebase1

enum class ProviderType {
    BASIC,
    GOOGLE
}